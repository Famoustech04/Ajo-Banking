
    function updateConnectionStatus() {  
        var status = document.getElementById("status");
        if(navigator.onLine) {
            status.innerHTML = '<div class="alert card card-style alert-dismissible show fade p-0 gradient-highlight shadow-bg shadow-bg-s rounded-m" role="alert" style="margin-top:10px;"><div class="content my-3"><div class="d-flex"><div class="align-self-center no-click1"><i class="bi bi-wifi font-36 d-block color-white scale-box"></i></div><div class="align-self-center no-click"><p class="color-white mb-0 font-500 font-14 ps-3 pe-4 line-height-s">Your connection is back online!<br>Stay Safe.</p></div></div></div><button type="button" class="btn-close opacity-20 font-11 pt-3 mt-1" data-bs-dismiss="alert" aria-label="Close"></button></div>';
status.classList.add("online");
status.classList.remove("offline");                        
        } else {
            status.innerHTML = '<div class="alert card card-style alert-dismissible show fade p-0 gradient-red shadow-bg shadow-bg-s" role="alert" style="margin-top:10px;"><div class="content my-3"><div class="d-flex"><div class="align-self-center no-click"><i class="bi bi-wifi-off font-36 d-block color-white scale-box"></i></div><div class="align-self-center no-click"><p class="color-white mb-0 font-500 font-14 ps-3 pe-4 line-height-s">You are currently ofline!<br>kindly check your internet cable.</p></div></div></div><button type="button" class="btn-close opacity-20 font-11 pt-3 mt-1" data-bs-dismiss="alert" aria-label="Close"></button></div>';
            status.classList.add("offline");
            status.classList.remove("online");            
        }
    }
    window.addEventListener("load", updateConnectionStatus);
    window.addEventListener("online", function(e) {
        updateConnectionStatus();
        status.innerHTML = "And we're back!";
    });
    window.addEventListener("offline", function(e) {        
        updateConnectionStatus();
        status.innerHTML = "Hey, it looks like you're offline.";
    });
